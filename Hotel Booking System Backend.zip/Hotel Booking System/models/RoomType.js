const mongoose = require('mongoose');

const roomTypeSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  description: String,
  basePrice: { type: Number, required: true },
  capacity: { type: Number, required: true },
}, { timestamps: true });

module.exports = mongoose.model('RoomType', roomTypeSchema);