const mongoose = require('mongoose');

const roomSchema = new mongoose.Schema({
  roomNumber: { type: String, required: true, unique: true },
  roomType: { type: mongoose.Schema.Types.ObjectId, ref: 'RoomType', required: true },
  pricePerNight: { type: Number, required: true },
  amenities: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Amenity' }],
  status: { 
    type: String, 
    enum: ['available', 'maintenance', 'booked'], 
    default: 'available' 
  },
}, { timestamps: true });

module.exports = mongoose.model('Room', roomSchema);