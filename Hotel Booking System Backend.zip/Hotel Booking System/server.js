const express = require('express');
const connectDB = require('./db');
const Guest = require('./models/Guest');
const Room = require('./models/Room');
const RoomType = require('./models/RoomType');
const Amenity = require('./models/Amenity');
const Booking = require('./models/Booking');
const swaggerUi = require('swagger-ui-express');
const swaggerJsdoc = require('swagger-jsdoc');
require('dotenv').config();

const app = express();
app.use(express.json());

// Connect to Database
connectDB();

// ========== GUEST CRUD ==========
app.get('/api/guests', async (req, res) => {
  try {
    const guests = await Guest.find();
    res.json(guests);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/guests', async (req, res) => {
  try {
    const guest = new Guest(req.body);
    await guest.save();
    res.status(201).json(guest);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

app.put('/api/guests/:id', async (req, res) => {
  try {
    const guest = await Guest.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!guest) return res.status(404).json({ error: 'Guest not found' });
    res.json(guest);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

app.delete('/api/guests/:id', async (req, res) => {
  try {
    const guest = await Guest.findByIdAndDelete(req.params.id);
    if (!guest) return res.status(404).json({ error: 'Guest not found' });
    res.json({ message: 'Guest deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ========== ROOM TYPE CRUD ==========
app.get('/api/roomtypes', async (req, res) => {
  try {
    const roomTypes = await RoomType.find();
    res.json(roomTypes);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/roomtypes', async (req, res) => {
  try {
    const rt = new RoomType(req.body);
    await rt.save();
    res.status(201).json(rt);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

app.put('/api/roomtypes/:id', async (req, res) => {
  try {
    const rt = await RoomType.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!rt) return res.status(404).json({ error: 'RoomType not found' });
    res.json(rt);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

app.delete('/api/roomtypes/:id', async (req, res) => {
  try {
    const rt = await RoomType.findByIdAndDelete(req.params.id);
    if (!rt) return res.status(404).json({ error: 'RoomType not found' });
    res.json({ message: 'RoomType deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ========== AMENITY CRUD ==========
app.get('/api/amenities', async (req, res) => {
  try {
    const amenities = await Amenity.find();
    res.json(amenities);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/amenities', async (req, res) => {
  try {
    const amenity = new Amenity(req.body);
    await amenity.save();
    res.status(201).json(amenity);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

app.put('/api/amenities/:id', async (req, res) => {
  try {
    const amenity = await Amenity.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!amenity) return res.status(404).json({ error: 'Amenity not found' });
    res.json(amenity);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

app.delete('/api/amenities/:id', async (req, res) => {
  try {
    const amenity = await Amenity.findByIdAndDelete(req.params.id);
    if (!amenity) return res.status(404).json({ error: 'Amenity not found' });
    res.json({ message: 'Amenity deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ========== ROOM CRUD (with Many-to-Many) ==========
app.get('/api/rooms', async (req, res) => {
  try {
    const rooms = await Room.find().populate('roomType').populate('amenities');
    res.json(rooms);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/rooms', async (req, res) => {
  try {
    const room = new Room(req.body);
    await room.save();
    await room.populate(['roomType', 'amenities']);
    res.status(201).json(room);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

app.put('/api/rooms/:id', async (req, res) => {
  try {
    const room = await Room.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true })
      .populate(['roomType', 'amenities']);
    if (!room) return res.status(404).json({ error: 'Room not found' });
    res.json(room);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/rooms/:id', async (req, res) => {
  try {
    const room = await Room.findByIdAndDelete(req.params.id);
    if (!room) return res.status(404).json({ error: 'Room not found' });
    res.json({ message: 'Room deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ========== Availability Helper (ONLY ONCE!) ==========
async function isRoomAvailable(roomId, checkIn, checkOut, excludeBookingId = null) {
  const query = {
    room: roomId,
    status: { $in: ['confirmed', 'pending'] },
    $or: [
      { checkInDate: { $lt: checkOut, $gte: checkIn } },
      { checkOutDate: { $gt: checkIn, $lte: checkOut } },
      { checkInDate: { $lte: checkIn }, checkOutDate: { $gte: checkOut } }
    ]
  };
  if (excludeBookingId) {
    query._id = { $ne: excludeBookingId };
  }
  const conflicting = await Booking.findOne(query);
  return !conflicting;
}

// ========== BOOKING CRUD ==========
app.get('/api/bookings', async (req, res) => {
  try {
    const bookings = await Booking.find().populate('guest').populate('room');
    res.json(bookings);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/bookings', async (req, res) => {
  try {
    const { guest, room, checkInDate, checkOutDate, totalPrice, status } = req.body;
    
    // Check availability
    const available = await isRoomAvailable(room, new Date(checkInDate), new Date(checkOutDate));
    if (!available) {
      return res.status(400).json({ error: 'Room is not available for the selected dates' });
    }
    
    const booking = new Booking({ guest, room, checkInDate, checkOutDate, totalPrice, status });
    await booking.save();
    await booking.populate('guest').populate('room');
    res.status(201).json(booking);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/bookings/:id', async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) return res.status(404).json({ error: 'Booking not found' });

    const { room, checkInDate, checkOutDate, ...updateData } = req.body;
    if ((room && room !== booking.room.toString()) || checkInDate || checkOutDate) {
      const newRoom = room || booking.room;
      const newCheckIn = checkInDate ? new Date(checkInDate) : booking.checkInDate;
      const newCheckOut = checkOutDate ? new Date(checkOutDate) : booking.checkOutDate;
      const available = await isRoomAvailable(newRoom, newCheckIn, newCheckOut, booking._id);
      if (!available) {
        return res.status(400).json({ error: 'Room is not available for the selected dates' });
      }
      booking.room = newRoom;
      booking.checkInDate = newCheckIn;
      booking.checkOutDate = newCheckOut;
    }
    Object.assign(booking, updateData);
    await booking.save();
    await booking.populate('guest').populate('room');
    res.json(booking);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

app.delete('/api/bookings/:id', async (req, res) => {
  try {
    const booking = await Booking.findByIdAndDelete(req.params.id);
    if (!booking) return res.status(404).json({ error: 'Booking not found' });
    res.json({ message: 'Booking deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ========== Availability Check Endpoint ==========
app.get('/api/rooms/:id/availability', async (req, res) => {
  try {
    const { checkIn, checkOut } = req.query;
    if (!checkIn || !checkOut) {
      return res.status(400).json({ error: 'checkIn and checkOut query params required' });
    }
    const available = await isRoomAvailable(req.params.id, new Date(checkIn), new Date(checkOut));
    res.json({ roomId: req.params.id, available });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ========== SWAGGER CONFIGURATION ==========
const swaggerOptions = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: '🏨 Hotel Booking API',
      version: '1.0.0',
      description: 'Complete CRUD API for Hotel Management System',
    },
    servers: [{ url: 'http://localhost:5000' }],
    components: {
      schemas: {
        Guest: {
          type: 'object',
          properties: {
            name: { type: 'string' },
            email: { type: 'string' },
            phone: { type: 'string' },
            address: { type: 'string' }
          }
        },
        RoomType: {
          type: 'object',
          properties: {
            name: { type: 'string' },
            basePrice: { type: 'number' },
            capacity: { type: 'number' }
          }
        },
        Amenity: {
          type: 'object',
          properties: {
            name: { type: 'string' },
            description: { type: 'string' }
          }
        },
        Room: {
          type: 'object',
          properties: {
            roomNumber: { type: 'string' },
            roomType: { type: 'string' },
            pricePerNight: { type: 'number' },
            amenities: { type: 'array', items: { type: 'string' } }
          }
        },
        Booking: {
          type: 'object',
          properties: {
            guest: { type: 'string' },
            room: { type: 'string' },
            checkInDate: { type: 'string', format: 'date' },
            checkOutDate: { type: 'string', format: 'date' },
            totalPrice: { type: 'number' },
            status: { type: 'string' }
          }
        }
      }
    },
    paths: {
      '/api/guests': {
        get: { summary: 'Get all guests', responses: { 200: { description: 'OK' } } },
        post: { summary: 'Create a guest', requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/Guest' } } } }, responses: { 201: { description: 'Created' } } }
      },
      '/api/guests/{id}': {
        put: { summary: 'Update a guest', parameters: [{ in: 'path', name: 'id' }], requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/Guest' } } } }, responses: { 200: { description: 'OK' } } },
        delete: { summary: 'Delete a guest', parameters: [{ in: 'path', name: 'id' }], responses: { 200: { description: 'Deleted' } } }
      },
      '/api/roomtypes': {
        get: { summary: 'Get all room types', responses: { 200: { description: 'OK' } } },
        post: { summary: 'Create a room type', requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/RoomType' } } } }, responses: { 201: { description: 'Created' } } }
      },
      '/api/roomtypes/{id}': {
        put: { summary: 'Update a room type', parameters: [{ in: 'path', name: 'id' }], requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/RoomType' } } } }, responses: { 200: { description: 'OK' } } },
        delete: { summary: 'Delete a room type', parameters: [{ in: 'path', name: 'id' }], responses: { 200: { description: 'Deleted' } } }
      },
      '/api/amenities': {
        get: { summary: 'Get all amenities', responses: { 200: { description: 'OK' } } },
        post: { summary: 'Create an amenity', requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/Amenity' } } } }, responses: { 201: { description: 'Created' } } }
      },
      '/api/amenities/{id}': {
        put: { summary: 'Update an amenity', parameters: [{ in: 'path', name: 'id' }], requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/Amenity' } } } }, responses: { 200: { description: 'OK' } } },
        delete: { summary: 'Delete an amenity', parameters: [{ in: 'path', name: 'id' }], responses: { 200: { description: 'Deleted' } } }
      },
      '/api/rooms': {
        get: { summary: 'Get all rooms (populated)', responses: { 200: { description: 'OK' } } },
        post: { summary: 'Create a room', requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/Room' } } } }, responses: { 201: { description: 'Created' } } }
      },
      '/api/rooms/{id}': {
        put: { summary: 'Update a room', parameters: [{ in: 'path', name: 'id' }], requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/Room' } } } }, responses: { 200: { description: 'OK' } } },
        delete: { summary: 'Delete a room', parameters: [{ in: 'path', name: 'id' }], responses: { 200: { description: 'Deleted' } } }
      },
      '/api/bookings': {
        get: { summary: 'Get all bookings (populated)', responses: { 200: { description: 'OK' } } },
        post: { summary: 'Create a booking (checks availability)', requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/Booking' } } } }, responses: { 201: { description: 'Created' }, 400: { description: 'Conflict error' } } }
      },
      '/api/bookings/{id}': {
        put: { summary: 'Update a booking', parameters: [{ in: 'path', name: 'id' }], requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/Booking' } } } }, responses: { 200: { description: 'OK' } } },
        delete: { summary: 'Delete a booking', parameters: [{ in: 'path', name: 'id' }], responses: { 200: { description: 'Deleted' } } }
      },
      '/api/rooms/{id}/availability': {
        get: {
          summary: 'Check room availability for dates',
          parameters: [
            { in: 'path', name: 'id' },
            { in: 'query', name: 'checkIn', schema: { type: 'string', format: 'date' } },
            { in: 'query', name: 'checkOut', schema: { type: 'string', format: 'date' } }
          ],
          responses: { 200: { description: 'Returns availability boolean' } }
        }
      }
    }
  },
  apis: ['./server.js'],
};

const swaggerSpec = swaggerJsdoc(swaggerOptions);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
console.log('📚 Swagger docs available at http://localhost:5000/api-docs');

// ========== Start Server ==========
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});