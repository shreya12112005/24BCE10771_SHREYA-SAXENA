🏨 Hotel Booking System Backend:
Overview
The Hotel Booking System Backend is a RESTful API developed using Node.js and MongoDB. It provides a complete backend solution for managing hotel operations, including guests, rooms, room types, amenities, and bookings. The system supports CRUD operations, database relationships, room availability checks, and booking conflict prevention.
This project demonstrates the use of MongoDB relationships, API development, and business logic implementation in a real-world hotel management scenario.
________________________________________
Technologies Used
•	Node.js – JavaScript runtime environment
•	MongoDB – NoSQL database
•	Mongoose – Object Data Modeling (ODM) library
•	Swagger UI – Interactive API documentation
________________________________________
Database Entities
The system consists of five main entities:
Guest
Stores customer information such as name, email, phone number, and address.
Room Type
Defines categories of rooms, including name, description, base price, and guest capacity.
Amenity
Stores facilities offered by rooms, such as Wi-Fi, television, or air conditioning.
Room
Contains room details including room number, room type, nightly price, amenities, and availability status.
Booking
Stores reservation details including guest, room, check-in date, check-out date, total price, and booking status.
________________________________________
Database Relationships
The project implements different database relationships:
One-to-Many
•	One Guest can have multiple Bookings.
•	One Room Type can contain multiple Rooms.
Many to One
•	A single room can have multiple amenities (Wi-Fi, TV, Air Conditioning, Mini Bar, etc.). 
•	A single amenity can be associated with multiple rooms.
Many-to-Many
•	A Room can have multiple Amenities.
•	The same Amenity can be assigned to multiple Rooms.
These relationships are managed using MongoDB ObjectId references and Mongoose population.
________________________________________
API Features
The API provides complete CRUD operations for all entities:

Guests
•	Create guest records
•	Retrieve guest information
•	Update guest details
•	Delete guests
Room Types
•	Create room categories
•	View room type information
•	Update room types
•	Delete room types
Amenities
•	Add amenities
•	Retrieve amenities
•	Update amenity information
•	Delete amenities
Rooms
•	Create rooms
•	View rooms with populated data
•	Update room information
•	Delete rooms
Bookings
•	Create bookings
•	Retrieve booking details
•	Update bookings
•	Cancel or delete bookings
________________________________________
Room Availability and Booking Logic
A special availability endpoint checks whether a room is available for a selected date range.
Before a booking is created, the system:
1.	Verifies the room exists.
2.	Checks existing bookings for overlapping dates.
3.	Prevents duplicate reservations.
4.	Returns availability status to the user.
This logic ensures that rooms cannot be double-booked.
Example response:
{
  "roomId": "67a1b2c3",
  "available": false
}
________________________________________
Swagger Documentation
The project includes Swagger UI for API testing and documentation.
Access Swagger at:
http://localhost:5000/api-docs
Features include:
•	Interactive API testing
•	Request and response examples
•	Endpoint descriptions
•	Schema visualization
________________________________________
Project Structure
hotel-booking-backend/
├── models/
│   ├── Guest.js
│   ├── Room.js
│   ├── RoomType.js
│   ├── Amenity.js
│   └── Booking.js
├── server.js
├── db.js
├── .env
├── package.json
└── README.md
________________________________________
Conclusion
The Hotel Booking System Backend is a scalable REST API that demonstrates backend development using Node.js, and MongoDB. It incorporates database relationships, booking validation, room availability checking, and comprehensive API documentation. The project serves as a practical example of building a real-world hotel reservation management system while following modern backend development practices.

